
## Code.Hub | Pfizer - Software & Cloud Engineering Bootcamp
 
  
#Sacchon 
 
###Project scope  
 
The project aim is to develop the Sacchon app and deliver it ready to be 
released. The requirements are given by the Sacchon Consulting Enterprise 
(a fictional company).  
 
