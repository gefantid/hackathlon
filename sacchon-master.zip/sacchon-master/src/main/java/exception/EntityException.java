package exception;

public class EntityException extends Exception {
    public EntityException(String message) {
        super(message);
    }

}
